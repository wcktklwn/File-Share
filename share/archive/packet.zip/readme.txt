Sample archive inside the share.
